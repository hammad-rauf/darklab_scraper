from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import DarklabItem

#from datetime import date


class DarkLabSpider(CrawlSpider):

    name = "darklab"

    img_link = "https:"

    start_urls = [
                "https://www.darklab.com/"
    ]

    rules = (
        Rule(LinkExtractor(restrict_css=([".menu-caption a",".next a"]))),
        Rule(LinkExtractor(restrict_css=("#collection-products-list li a")),callback="darklab"),  
    )


    def darklab(self, response):

        products = DarklabItem()

        products["title"] = response.css(".product-data h1::text").extract_first()
        products["price"] = response.css(".products-offers span::text").extract_first()
        products["images"] = response.css("#lens + .product-image-thumbs img::attr(src)").extract()

        for img in range(len(products["images"])):
            temp = self.img_link
            products["images"][img] = temp + products["images"][img]

        products["url"] = response.url

        products["description"] = response.css("#tab-1 li::text").extract()

        if not products["description"]:
            products["description"] = response.css("#tab-1 p::text").extract()
        
        if not products["description"]:
            products["description"] = response.css("#product-description li::text").extract()

        if not products["description"]:
            products["description"] = response.css("#product-description span::text").extract()

        if not products["description"]:
            products["description"] = response.css("#product-description p::text").extract()


        products["option"] = response.css("#variant-select option::text").extract()

        for option in range(len(products["option"])):
            products["option"][option] = products["option"][option].strip("\n")
            products["option"][option] = products["option"][option].strip(" ")
            products["option"][option] = products["option"][option].replace(" - Sold out","")
            


        yield products
 
